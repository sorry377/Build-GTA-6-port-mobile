package com.overallai

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private data class AppEntry(val label: String, val packageName: String) {
        override fun toString(): String = "$label  ·  $packageName"
    }

    private lateinit var firstGame: Spinner
    private lateinit var secondGame: Spinner
    private lateinit var status: TextView
    private lateinit var privilegeStatus: TextView
    private var apps: List<AppEntry> = emptyList()

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == SHIZUKU_REQUEST) {
            privilegeStatus.text = if (grantResult == PackageManager.PERMISSION_GRANTED) {
                "Shizuku: อนุญาตแล้ว (UID ${safeShizukuUid()})"
            } else {
                "Shizuku: ไม่ได้รับอนุญาต"
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(10, 12, 22)
        window.navigationBarColor = Color.rgb(10, 12, 22)
        Shizuku.addRequestPermissionResultListener(permissionListener)
        buildUi()
        loadApps()
        refreshPrivilegeStatus()
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        super.onDestroy()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(26), dp(20), dp(28))
            setBackgroundColor(Color.rgb(10, 12, 22))
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(label("OVERALL AI", 30, Color.WHITE, true))
        root.addView(label("DUAL GAME ENVIRONMENT  •  ANDROID", 11, Color.rgb(130, 160, 220)))
        root.addView(space(22))

        root.addView(label("เลือกเกมที่ต้องการนำเข้า", 16, Color.WHITE, true))
        firstGame = spinner()
        root.addView(firstGame)
        root.addView(space(14))
        root.addView(label("เลือกเกมหลัก (เกมที่ 2)", 16, Color.WHITE, true))
        secondGame = spinner()
        root.addView(secondGame)
        root.addView(space(18))

        root.addView(label("PRIVILEGE STATUS", 13, Color.rgb(120, 190, 255), true))
        privilegeStatus = label("กำลังตรวจสอบ...", 14, Color.LTGRAY)
        root.addView(privilegeStatus)
        root.addView(space(10))

        val shizukuButton = button("ขอสิทธิ์ Shizuku") { requestShizukuPermission() }
        root.addView(shizukuButton)
        root.addView(space(8))
        root.addView(button("ตรวจสอบ Root อีกครั้ง") {
            val rooted = hasRoot()
            status.text = if (rooted) "Root: พบสิทธิ์ su" else "Root: ไม่พบหรือยังไม่ได้อนุญาต"
            refreshPrivilegeStatus()
        })
        root.addView(space(22))

        root.addView(label("EMBEDDED SESSION", 13, Color.rgb(120, 190, 255), true))
        root.addView(label(
            "โหมด Embedded ต้องใช้ Virtual Display ที่สร้างโดยสิทธิ์ระดับระบบ และตัวเกมต้องอนุญาตให้เปิดบน Display รอง",
            13, Color.LTGRAY
        ))
        root.addView(space(10))
        root.addView(button("ตรวจสอบความพร้อมและเริ่มเซสชัน") { checkEmbeddedReadiness() })
        root.addView(space(12))

        status = label(
            "สถานะ: ยังไม่ได้เริ่มเซสชัน\n\nหมายเหตุ: รุ่นนี้เป็นโครงสร้าง MVP สำหรับเลือกแอปและตรวจสอบสิทธิ์ ยังไม่ฝังภาพเกมจริงลงใน Surface ของอีกเกม",
            13, Color.rgb(220, 220, 230)
        )
        status.setPadding(dp(14), dp(14), dp(14), dp(14))
        status.setBackgroundColor(Color.rgb(24, 29, 45))
        root.addView(status)
        root.addView(space(20))
        root.addView(label("Overall AI 0.1.0 • Prototype", 11, Color.GRAY))
    }

    private fun loadApps() {
        val pm = packageManager
        apps = try {
            pm.getInstalledApplications(PackageManager.GET_META_DATA)
                .filter { it.packageName != packageName }
                .map { AppEntry(pm.getApplicationLabel(it).toString(), it.packageName) }
                .sortedBy { it.label.lowercase() }
        } catch (_: Exception) {
            emptyList()
        }

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, apps).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        firstGame.adapter = adapter
        secondGame.adapter = adapter
        if (apps.isEmpty()) {
            status.text = "ไม่พบรายการแอป ตรวจสอบ Package visibility และสิทธิ์ของระบบ"
        }
    }

    private fun requestShizukuPermission() {
        try {
            if (!Shizuku.pingBinder()) {
                privilegeStatus.text = "Shizuku: ยังไม่ทำงาน กรุณาเปิดแอป Shizuku ก่อน"
                return
            }
            if (Shizuku.isPreV11()) {
                privilegeStatus.text = "Shizuku API รุ่นเก่าเกินไป ต้องใช้ v11 ขึ้นไป"
                return
            }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                privilegeStatus.text = "Shizuku: อนุญาตแล้ว (UID ${safeShizukuUid()})"
            } else {
                Shizuku.requestPermission(SHIZUKU_REQUEST)
            }
        } catch (e: Exception) {
            privilegeStatus.text = "Shizuku error: ${e.message ?: "ตรวจสอบไม่ได้"}"
        }
    }

    private fun safeShizukuUid(): Int = try { Shizuku.getUid() } catch (_: Exception) { -1 }

    private fun hasRoot(): Boolean = try {
        val process = ProcessBuilder("su", "-c", "id")
            .redirectErrorStream(true).start()
        val output = process.inputStream.bufferedReader().use { it.readText() }
        process.waitFor() == 0 && output.contains("uid=0")
    } catch (_: Exception) {
        false
    }

    private fun refreshPrivilegeStatus() {
        val shizuku = try {
            if (Shizuku.pingBinder()) "พร้อม (UID ${safeShizukuUid()})" else "ไม่ทำงาน"
        } catch (_: Exception) { "ไม่พร้อมใช้งาน" }
        val root = if (hasRoot()) "พบ Root" else "ไม่พบ Root"
        privilegeStatus.text = "Shizuku: $shizuku\nRoot: $root"
    }

    private fun checkEmbeddedReadiness() {
        val one = firstGame.selectedItem as? AppEntry
        val two = secondGame.selectedItem as? AppEntry
        if (one == null || two == null) {
            status.text = "กรุณาเลือกแอปทั้งสองช่องก่อน"
            return
        }
        if (one.packageName == two.packageName) {
            status.text = "กรุณาเลือกเกมคนละแอป"
            return
        }
        val shizukuReady = try { Shizuku.pingBinder() } catch (_: Exception) { false }
        val rootReady = hasRoot()
        status.text = buildString {
            append("ตรวจสอบการเลือกแอปเรียบร้อย\n")
            append("Game 1: ${one.label} (${one.packageName})\n")
            append("Game 2: ${two.label} (${two.packageName})\n\n")
            append("Shizuku: ${if (shizukuReady) "พร้อม" else "ไม่พร้อม"}\n")
            append("Root: ${if (rootReady) "พบ" else "ไม่พบ"}\n\n")
            append("ยังไม่สามารถเริ่ม Embedded session ได้: โปรเจกต์รุ่นนี้ยังไม่มี privileged Virtual Display host/service ")
            append("และยังไม่ได้ทดสอบ compatibility กับเกมที่เลือก จึงไม่เปิดเกมหลอกว่าอยู่ภายในอีกเกม")
        }
    }

    private fun spinner(): Spinner = Spinner(this).apply {
        background = null
    }

    private fun button(text: String, action: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(42, 91, 170))
            setOnClickListener { action() }
        }

    private fun label(text: String, size: Int, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(4), 0, dp(4))
        }

    private fun space(height: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object { private const val SHIZUKU_REQUEST = 1001 }
}

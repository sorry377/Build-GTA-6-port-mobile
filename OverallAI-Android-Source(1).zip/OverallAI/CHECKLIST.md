# Pre-build review

- [x] App module and namespace are aligned (`com.overallai`).
- [x] Manifest declares package visibility for installed-app picker.
- [x] Shizuku provider authority uses `${applicationId}.shizuku`.
- [x] Shizuku permission listener is removed in `onDestroy`.
- [x] Shizuku Binder is checked before requesting permission.
- [x] Root check verifies command exit code and `uid=0`; it does not assume that `su` existing means root was granted.
- [x] Game 1 and Game 2 must be different packages.
- [x] Workflow uses JDK 17, Android API 36 and build-tools 36.0.0.
- [x] Workflow uploads `app-debug.apk` and fails if it is missing.
- [ ] Generate and commit Gradle wrapper files before running workflow.
- [ ] Run GitHub Actions build; this environment did not have Android SDK.
- [ ] Install and test on target Android device.
- [ ] Implement and validate a privileged virtual-display host before advertising Embedded mode as functional.

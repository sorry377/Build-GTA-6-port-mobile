# NEXRA Executor ProGuard rules
-keep class com.nexra.robloxexecutor.** { *; }

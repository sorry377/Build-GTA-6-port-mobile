package com.nexra.robloxexecutor

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.documentfile.provider.DocumentFile
import java.io.BufferedReader
import java.io.InputStreamReader
import java.nio.charset.StandardCharsets
import java.util.zip.ZipInputStream
import java.util.concurrent.Executors
import java.util.concurrent.Future

class ExecutorActivity : AppCompatActivity() {
    private lateinit var luaInput: EditText
    private lateinit var btnRun: Button
    private lateinit var btnCheck: Button
    private lateinit var outputLog: TextView
    private val worker = Executors.newSingleThreadExecutor()
    @Volatile private var running: Future<*>? = null
    private val scriptsDirectory by lazy { java.io.File(filesDir, "scripts").apply { mkdirs() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_executor)

        luaInput = findViewById(R.id.luaInput)
        btnRun = findViewById(R.id.btnRun)
        btnCheck = findViewById(R.id.btnCheck)
        outputLog = findViewById(R.id.outputLog)
        outputLog.text = "NEXRA LOCAL EXECUTION ENVIRONMENT\nLua 5.1 VM: initializing...\nNo external app process is attached.\n"

        val runtime = ScriptRuntime(scriptsDirectory) { line -> log("[print] $line") }
        log("[READY] Execution Environment")
        log("[READY] Lua 5.1 Runtime")
        log("[READY] Script Compiler / Parser")
        log("[READY] Script Scheduler (single worker + stop)")
        log("[READY] Output Console / Error Handler")
        log("[READY] Filesystem API: app-private scripts/")
        log("[READY] Environment Manager: isolated globals per run")
        log("[READY] HTTP Interface: http_get() with response limit")
        log("[INFO] GUI Renderer is this local editor/console; Roblox GUI API is not connected")
        log("[INFO] Luau VM is separate from standard Lua 5.1 and is not bundled")

        btnRun.setOnClickListener {
            val source = luaInput.text.toString()
            if (source.isBlank()) {
                Toast.makeText(this, "ใส่ Lua script ก่อน", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (running?.isDone == false) {
                Toast.makeText(this, "มีสคริปต์กำลังทำงานอยู่", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            btnRun.isEnabled = false
            btnCheck.isEnabled = false
            log("\n[RUN] Starting in local Lua 5.1 VM...")
            running = worker.submit {
                try {
                    runtime.execute(source)
                    log("[OK] Script completed")
                } catch (error: Throwable) {
                    log("[ERROR] ${error.message ?: error.javaClass.simpleName}")
                } finally {
                    runOnUiThread {
                        btnRun.isEnabled = true
                        btnCheck.isEnabled = true
                    }
                }
            }
        }

        btnCheck.setOnClickListener {
            val source = luaInput.text.toString()
            try {
                runtime.validate(source)
                log("[COMPILE] Syntax OK — parsed by Lua 5.1 VM")
            } catch (error: Throwable) {
                log("[COMPILE ERROR] ${error.message ?: error.javaClass.simpleName}")
            }
        }

        findViewById<Button>(R.id.btnStop).setOnClickListener {
            running?.cancel(true)
            log("[STOP] Cancellation requested")
            btnRun.isEnabled = true
            btnCheck.isEnabled = true
        }
        findViewById<Button>(R.id.btnClear).setOnClickListener {
            luaInput.setText("")
            log("[EDITOR] Cleared")
        }
        findViewById<Button>(R.id.btnFolder).setOnClickListener { chooseFolder() }
        findViewById<Button>(R.id.btnZip).setOnClickListener { chooseZip() }

        if (intent?.data != null) {
            loadUri(intent.data!!)
        } else {
            val savedFolder = getSharedPreferences("nexra_files", MODE_PRIVATE)
                .getString("folder_uri", null)
            if (!savedFolder.isNullOrBlank()) {
                scanFolder(Uri.parse(savedFolder), chooseFile = false)
            }
        }
    }

    private fun chooseFolder() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
        )
        startActivityForResult(intent, REQUEST_FOLDER)
    }

    private fun chooseZip() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/zip"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivityForResult(intent, REQUEST_ZIP)
    }

    @Deprecated("Handled for compatibility with Android document picker")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        val uri = data.data!!
        when (requestCode) {
            REQUEST_FOLDER -> {
                try {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) { }
                getSharedPreferences("nexra_files", MODE_PRIVATE).edit()
                    .putString("folder_uri", uri.toString()).apply()
                scanFolder(uri)
            }
            REQUEST_ZIP -> readZip(uri)
        }
    }

    private fun scanFolder(uri: Uri, chooseFile: Boolean = true) {
        val root = DocumentFile.fromTreeUri(this, uri)
        if (root == null) {
            log("[FILES] Cannot open selected folder")
            return
        }
        val found = mutableListOf<DocumentFile>()
        collectScripts(root, found, 0)
        if (found.isEmpty()) {
            log("[FILES] No .lua or .txt files found")
            return
        }
        log("[FILES] Scanned folder: ${found.size} Lua/text files available")
        if (chooseFile) {
            val labels = found.map { it.name ?: "unnamed script" }.toTypedArray()
            AlertDialog.Builder(this)
                .setTitle("Scripts found (${found.size})")
                .setItems(labels) { _, index ->
                    val file = found[index]
                    try {
                        val source = contentResolver.openInputStream(file.uri)?.use { it.readBytesLimited(MAX_IMPORT_BYTES) }
                            ?: error("Cannot read file")
                        luaInput.setText(String(source, StandardCharsets.UTF_8))
                        log("[FILES] Loaded ${file.name}")
                    } catch (error: Exception) {
                        log("[FILES ERROR] ${error.message}")
                    }
                }
                .setNegativeButton("Close", null)
                .show()
        }
    }

    private fun collectScripts(folder: DocumentFile, output: MutableList<DocumentFile>, depth: Int) {
        if (depth > 10 || output.size >= 300) return
        folder.listFiles().forEach { child ->
            if (child.isDirectory) collectScripts(child, output, depth + 1)
            else {
                val name = child.name?.lowercase().orEmpty()
                if (name.endsWith(".lua") || name.endsWith(".txt")) output.add(child)
            }
        }
    }

    private fun readZip(uri: Uri) {
        val scripts = linkedMapOf<String, String>()
        var skippedNative = 0
        var totalBytes = 0
        try {
            val input = contentResolver.openInputStream(uri) ?: error("Cannot open ZIP")
            ZipInputStream(input).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    if (!entry.isDirectory) {
                        val name = entry.name.substringAfterLast('/').substringAfterLast('\\')
                        val lower = name.lowercase()
                        if (lower.endsWith(".dll") || lower.endsWith(".exe") || lower.endsWith(".so")) {
                            skippedNative++
                        } else if (lower.endsWith(".lua") || lower.endsWith(".txt")) {
                            val bytes = zip.readBytesLimited(MAX_IMPORT_BYTES - totalBytes)
                            totalBytes += bytes.size
                            if (totalBytes > MAX_IMPORT_BYTES) error("ZIP import exceeds 2 MB")
                            scripts[entry.name] = String(bytes, StandardCharsets.UTF_8)
                        }
                    }
                    zip.closeEntry()
                    if (scripts.size >= 100) break
                }
            }
            if (scripts.isEmpty()) {
                log("[ZIP] No Lua/text script found. Native binaries are not executable here.")
                return
            }
            val names = scripts.keys.toTypedArray()
            AlertDialog.Builder(this)
                .setTitle("Choose Lua file from ZIP")
                .setItems(names) { _, index ->
                    luaInput.setText(scripts[names[index]])
                    log("[ZIP] Loaded ${names[index]}")
                }
                .setNegativeButton("Close", null)
                .show()
            log("[ZIP] Found ${scripts.size} Lua/text files; skipped $skippedNative DLL/EXE/SO file(s)")
        } catch (error: Exception) {
            log("[ZIP ERROR] ${error.message ?: error.javaClass.simpleName}")
        }
    }

    private fun loadUri(uri: Uri) {
        try {
            val source = contentResolver.openInputStream(uri)?.use { it.readBytesLimited(MAX_IMPORT_BYTES) }
                ?: error("Cannot read selected file")
            luaInput.setText(String(source, StandardCharsets.UTF_8))
        } catch (error: Exception) {
            log("[IMPORT ERROR] ${error.message}")
        }
    }

    private fun java.io.InputStream.readBytesLimited(limit: Int): ByteArray {
        require(limit > 0) { "Import size limit reached" }
        val output = java.io.ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        var total = 0
        while (true) {
            val count = read(buffer)
            if (count < 0) break
            total += count
            require(total <= limit) { "File exceeds import size limit" }
            output.write(buffer, 0, count)
        }
        return output.toByteArray()
    }

    private fun log(message: String) {
        runOnUiThread {
            outputLog.append("\n$message")
            val scroll = findViewById<ScrollView>(R.id.outputScroll)
            scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
        }
    }

    override fun onDestroy() {
        running?.cancel(true)
        worker.shutdownNow()
        super.onDestroy()
    }

    companion object {
        private const val REQUEST_FOLDER = 4201
        private const val REQUEST_ZIP = 4202
        private const val MAX_IMPORT_BYTES = 2 * 1024 * 1024
    }
}

package com.nexra.robloxexecutor

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var processList: ListView
    private lateinit var statusText: TextView
    private lateinit var searchInput: EditText
    private lateinit var overlayButton: Button
    private var allApps: List<String> = emptyList()
    private var overlayStarted = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        processList = findViewById(R.id.processList)
        statusText = findViewById(R.id.statusText)
        searchInput = findViewById(R.id.searchInput)
        overlayButton = findViewById(R.id.btnOverlay)
        val openEditor: Button = findViewById(R.id.btnLoad)
        val refresh: Button = findViewById(R.id.btnRefresh)

        openEditor.setOnClickListener {
            startActivity(Intent(this, ExecutorActivity::class.java))
        }
        refresh.setOnClickListener { refreshApps() }
        overlayButton.setOnClickListener { toggleOverlay() }

        searchInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                showApps(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: Editable?) = Unit
        })

        processList.setOnItemClickListener { _, _, position, _ ->
            val item = processList.adapter.getItem(position).toString()
            Toast.makeText(this, "$item\nตรวจพบแอปเท่านั้น ไม่ได้เชื่อมต่อ VM ภายในแอป", Toast.LENGTH_LONG).show()
        }
        refreshApps()
    }

    override fun onResume() {
        super.onResume()
        if (Settings.canDrawOverlays(this) && !overlayStarted) {
            startService(Intent(this, OverlayService::class.java))
            overlayStarted = true
        }
        updateOverlayState()
    }

    private fun refreshApps() {
        statusText.text = "กำลังตรวจหารายการแอปที่ติดตั้ง..."
        Thread {
            val pm = packageManager
            val apps = try {
                pm.getInstalledApplications(0)
                    .filter { it.packageName != packageName }
                    .map { info ->
                        val label = try { info.loadLabel(pm).toString() } catch (_: Exception) { info.packageName }
                        "$label  ·  ${info.packageName}  ·  ตรวจพบ"
                    }
                    .sortedBy { it.lowercase() }
            } catch (error: Exception) {
                emptyList()
            }
            allApps = apps
            runOnUiThread {
                showApps(searchInput.text.toString())
                statusText.text = "NEXRA UI READY  •  พบ ${apps.size} แอปในเครื่อง\nLua VM จะเริ่มเมื่อเปิด Console • แอปที่แสดงคือรายการที่ตรวจพบเท่านั้น"
                statusText.setTextColor(0xFF00FF88.toInt())
            }
        }.start()
    }

    private fun showApps(query: String) {
        val filtered = if (query.isBlank()) allApps else allApps.filter { it.contains(query, true) }
        processList.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, filtered)
    }

    private fun toggleOverlay() {
        if (Settings.canDrawOverlays(this)) {
            if (overlayStarted) {
                stopService(Intent(this, OverlayService::class.java))
                overlayStarted = false
            } else {
                startService(Intent(this, OverlayService::class.java))
                overlayStarted = true
            }
            updateOverlayState()
            return
        }
        val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        @Suppress("DEPRECATION")
        startActivityForResult(intent, REQUEST_OVERLAY)
    }

    @Deprecated("Handled for compatibility with Android's overlay permission screen")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_OVERLAY) {
            if (Settings.canDrawOverlays(this)) {
                startService(Intent(this, OverlayService::class.java))
                overlayStarted = true
            } else {
                Toast.makeText(this, "ยังไม่ได้อนุญาตแสดงทับแอปอื่น", Toast.LENGTH_SHORT).show()
            }
            updateOverlayState()
        }
    }

    private fun updateOverlayState() {
        val permitted = Settings.canDrawOverlays(this)
        overlayButton.text = when {
            !permitted -> "อนุญาต Floating Icon"
            overlayStarted -> "ปิด Floating Icon"
            else -> "เปิด Floating Icon"
        }
    }

    companion object { private const val REQUEST_OVERLAY = 4102 }
}

package com.nexra.robloxexecutor

import org.luaj.vm2.Globals
import org.luaj.vm2.LuaError
import org.luaj.vm2.LuaValue
import org.luaj.vm2.Varargs
import org.luaj.vm2.lib.OneArgFunction
import org.luaj.vm2.lib.VarArgFunction
import org.luaj.vm2.lib.jse.JsePlatform
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets

/**
 * Runs standard Lua 5.1 scripts inside this application's own VM.
 * It deliberately does not expose Android internals, Java reflection,
 * native loading, process access, or another application's Lua state.
 */
class ScriptRuntime(
    private val scriptsDirectory: File,
    private val emit: (String) -> Unit
) {
    fun validate(source: String) {
        require(source.isNotBlank()) { "สคริปต์ว่าง" }
        require(source.length <= MAX_SOURCE_CHARS) { "สคริปต์ใหญ่เกินกำหนด (สูงสุด ${MAX_SOURCE_CHARS} ตัวอักษร)" }
        createGlobals().load(source, "@nexra-check")
    }

    fun execute(source: String) {
        require(source.isNotBlank()) { "สคริปต์ว่าง" }
        require(source.length <= MAX_SOURCE_CHARS) { "สคริปต์ใหญ่เกินกำหนด (สูงสุด ${MAX_SOURCE_CHARS} ตัวอักษร)" }
        val globals = createGlobals()
        val chunk = globals.load(source, "@nexra-local")
        chunk.call()
    }

    private fun createGlobals(): Globals {
        scriptsDirectory.mkdirs()
        val globals = JsePlatform.standardGlobals()

        // Keep the normal Lua language libraries, but remove host-level escape hatches.
        listOf("io", "os", "package", "debug", "luajava", "dofile", "loadfile", "loadstring", "require")
            .forEach { globals.set(it, LuaValue.NIL) }

        globals.set("print", object : VarArgFunction() {
            override fun invoke(args: Varargs): Varargs {
                val parts = (1..args.narg()).map { args.arg(it).tojstring() }
                emit(parts.joinToString("\t"))
                return LuaValue.NONE
            }
        })

        val waitFunction = object : OneArgFunction() {
            override fun call(arg: LuaValue): LuaValue {
                val millis = (arg.todouble().coerceIn(0.0, 5.0) * 1000.0).toLong()
                try {
                    Thread.sleep(millis)
                } catch (interrupted: InterruptedException) {
                    Thread.currentThread().interrupt()
                    throw LuaError("Execution cancelled")
                }
                return LuaValue.NIL
            }
        }
        globals.set("wait", waitFunction)
        val taskTable = LuaValue.tableOf()
        taskTable.set("wait", waitFunction)
        globals.set("task", taskTable)

        globals.set("fs_read", object : OneArgFunction() {
            override fun call(arg: LuaValue): LuaValue {
                val file = safeScriptFile(arg.checkjstring())
                if (!file.exists()) throw LuaError("File not found: ${file.name}")
                if (file.length() > MAX_FILE_BYTES) throw LuaError("File too large")
                return LuaValue.valueOf(file.readText(StandardCharsets.UTF_8))
            }
        })
        globals.set("fs_write", object : VarArgFunction() {
            override fun invoke(args: Varargs): Varargs {
                val name = args.arg(1).checkjstring()
                val content = args.arg(2).checkjstring()
                require(content.toByteArray(StandardCharsets.UTF_8).size <= MAX_FILE_BYTES) { "File too large" }
                safeScriptFile(name).writeText(content, StandardCharsets.UTF_8)
                return LuaValue.TRUE
            }
        })

        // HTTP is a data API only: the returned text is never evaluated as code.
        globals.set("http_get", object : OneArgFunction() {
            override fun call(arg: LuaValue): LuaValue {
                val url = URL(arg.checkjstring())
                require(url.protocol.equals("https", true) || url.protocol.equals("http", true)) {
                    "Only HTTP/HTTPS URLs are supported"
                }
                val connection = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 8_000
                    readTimeout = 8_000
                    instanceFollowRedirects = false
                    setRequestProperty("User-Agent", "NEXRA-Local-Lua/1.0")
                }
                try {
                    val stream = if (connection.responseCode >= 400) connection.errorStream else connection.inputStream
                    val bytes = stream?.use { input ->
                        val output = java.io.ByteArrayOutputStream()
                        val buffer = ByteArray(8 * 1024)
                        var total = 0
                        while (true) {
                            val read = input.read(buffer)
                            if (read < 0) break
                            total += read
                            if (total > MAX_HTTP_BYTES) throw LuaError("HTTP response exceeds 512 KB")
                            output.write(buffer, 0, read)
                        }
                        output.toByteArray()
                    } ?: ByteArray(0)
                    if (connection.responseCode !in 200..299) {
                        throw LuaError("HTTP ${connection.responseCode}")
                    }
                    return LuaValue.valueOf(String(bytes, StandardCharsets.UTF_8))
                } finally {
                    connection.disconnect()
                }
            }
        })

        return globals
    }

    private fun safeScriptFile(name: String): File {
        require(name.matches(Regex("[A-Za-z0-9_.-]{1,80}\\.(lua|txt)"))) {
            "Use a simple .lua or .txt file name"
        }
        require(!name.contains("..")) { "Invalid file name" }
        val root = scriptsDirectory.canonicalFile
        val candidate = File(root, name).canonicalFile
        require(candidate.parentFile == root) { "Invalid file path" }
        return candidate
    }

    companion object {
        const val MAX_SOURCE_CHARS = 100_000
        private const val MAX_FILE_BYTES = 512 * 1024
        private const val MAX_HTTP_BYTES = 512 * 1024
    }
}

# NEXRA Local Runtime (Android)

An Android Lua 5.1 editor and local execution sandbox. Scripts execute inside NEXRA's own VM only.
The installed-app list is informational; it does not attach to, inject into, or execute code inside other apps.

## Implemented

- Lua 5.1 interpreter powered by LuaJ 2.0.3.
- Local run, syntax/compile check, stop request, output console, and error reporting.
- Fresh Lua globals for each run; Java reflection, `luajava`, `io`, `os`, `package`, `debug`, `require`, and file-loading escape hatches are removed.
- `print(...)`, `wait(seconds)`, and `task.wait(seconds)`.
- `http_get(url)` for HTTP(S) text responses (8-second timeout; 512 KB response cap). Returned text is data and is not evaluated.
- `fs_read("name.lua")` and `fs_write("name.lua", "contents")` inside the app-private `files/scripts/` folder only.
- Android Storage Access Framework folder scan for `.lua`/`.txt` files.
- ZIP inspection and import for `.lua`/`.txt` entries. DLL/EXE/SO entries are listed as skipped and are not executed.
- Optional movable floating NEXRA icon using Android's overlay permission.
- Installed-app inventory with a truthful `ตรวจพบ` status.

## Not included

- No Roblox process attachment, DLL injection, anti-ban/anti-kick bypass, server-side execution, or remote-game API.
- No arbitrary DLL/EXE/native library execution.
- No Shizuku integration. Merely declaring the Shizuku permission does not grant its API or create a VM bridge.
- Luau is a separate VM/language implementation; this build bundles standard Lua 5.1, not the Luau runtime.
- `GUI Renderer` means the editor and output console UI. It is not a Roblox `Instance`/Drawing API.

## Build APK in GitHub Actions

1. Create a GitHub repository and upload this ZIP to its root, naming it `RobloxExecutor.zip`.
2. In that repository, create `.github/workflows/build.yml` and paste in the separate `build.yml` file supplied with this project. GitHub only discovers workflow files in the repository-root `.github/workflows/` folder.
3. Open **Actions → Build NEXRA Android APK → Run workflow**.
4. Download the `NEXRA-Local-Runtime-APK` artifact from the completed workflow run.

## Build locally

Open the project in Android Studio and run **Build → Build APK(s)**. The project uses JDK 17, Gradle 8.7, and Android SDK 34.

## Floating icon

Open the app and tap **เปิด Floating Icon**. Android will ask for "Display over other apps" permission. Grant it, then tap the button again if the icon did not appear. Tap the green `N` icon to reopen the local Lua console; drag it to move it.

## Lua examples

```lua
print("Hello from Lua 5.1")
print("2 + 3 =", 2 + 3)
wait(0.25)

fs_write("hello.txt", "saved inside NEXRA")
print(fs_read("hello.txt"))
```

```lua
local body = http_get("https://example.com/")
print("Downloaded characters:", #body)
```

package com.neoncoast.game

import android.opengl.GLES20.*
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.util.Log
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.*

class Renderer : GLSurfaceView.Renderer {
    private var prog = 0; private var skyProg = 0
    private var uVP = 0; private var uM = 0; private var uCol = 0; private var uSun = 0; private var uCam = 0
    private var uFog = 0; private var uWin = 0; private var uEmis = 0; private var uRoad = 0
    private var aPos = 0; private var aNrm = 0; private var sPos = 0; private var sHor = 0
    private var cubeVbo = 0; private var quadVbo = 0
    private var aspect = 1.7f; private var last = 0L
    private val proj = FloatArray(16); private val view = FloatArray(16)
    private val vp = FloatArray(16); private val mm = FloatArray(16)

    private val VS = """
uniform mat4 uVP; uniform mat4 uM;
attribute vec3 aPos; attribute vec3 aNrm;
varying vec3 vN; varying vec3 vW;
void main(){
  vec4 w = uM * vec4(aPos, 1.0);
  vW = w.xyz;
  vN = (uM * vec4(aNrm, 0.0)).xyz;
  gl_Position = uVP * w;
}"""

    private val FS = """
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
uniform vec3 uCol; uniform vec3 uSun; uniform vec3 uCam; uniform vec3 uFog;
uniform float uWin; uniform float uEmis; uniform vec2 uRoad;
varying vec3 vN; varying vec3 vW;
float hs(vec2 p){ return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }
void main(){
  vec3 n = normalize(vN);
  float dif = max(dot(n, uSun), 0.0);
  vec3 amb = mix(vec3(0.22, 0.20, 0.28), vec3(0.55, 0.45, 0.42), n.y * 0.5 + 0.5);
  vec3 c = uCol; vec3 em = vec3(0.0);
  if (uWin > 0.5 && abs(n.y) < 0.5) {
    vec2 uv = vec2((vW.x + vW.z) / 3.2, vW.y / 3.6);
    vec2 f = fract(uv); vec2 id = floor(uv);
    float inw = step(0.2, f.x) * step(f.x, 0.8) * step(0.25, f.y) * step(f.y, 0.8);
    float lit = step(0.55, hs(id + vec2(floor(uWin), 0.0)));
    vec3 wc = mix(vec3(0.07, 0.09, 0.14), vec3(1.0, 0.8, 0.48), lit);
    c = mix(c, wc, inw);
    em = wc * inw * lit * 0.75;
  }
  if (uRoad.x > 0.5 && abs(n.y) > 0.5) {
    float a = uRoad.x < 1.5 ? vW.x : vW.z;
    float ac = uRoad.x < 1.5 ? (vW.z - uRoad.y) : (vW.x - uRoad.y);
    float m = mod(a + 320.0, 80.0);
    if (m > 11.0 && m < 69.0) {
      if (mod(a, 8.0) < 4.0 && abs(ac) < 0.2) c = vec3(0.95, 0.85, 0.4);
      if (abs(abs(ac) - 8.4) < 0.12) c = vec3(0.8);
    }
  }
  vec3 col = c * (amb + vec3(1.0, 0.76, 0.52) * dif * 1.2) + em + uEmis * uCol;
  float dist = length(vW - uCam);
  float fg = clamp((dist - 90.0) / 470.0, 0.0, 1.0);
  col = mix(col, uFog, fg * fg * (3.0 - 2.0 * fg));
  gl_FragColor = vec4(col, 1.0);
}"""

    private val SVS = """
attribute vec2 p; varying float vy;
void main(){ vy = p.y; gl_Position = vec4(p, 0.999, 1.0); }"""

    private val SFS = """
precision mediump float;
varying float vy; uniform float uHor;
void main(){
  float t = clamp((vy - uHor) / 1.6, 0.0, 1.0);
  vec3 hor = vec3(0.97, 0.72, 0.5); vec3 mid = vec3(0.75, 0.40, 0.45); vec3 top = vec3(0.12, 0.17, 0.42);
  vec3 c = t < 0.35 ? mix(hor, mid, t / 0.35) : mix(mid, top, (t - 0.35) / 0.65);
  if (vy < uHor) c = hor;
  gl_FragColor = vec4(c, 1.0);
}"""

    private fun sh(type: Int, src: String): Int {
        val s = glCreateShader(type)
        glShaderSource(s, src); glCompileShader(s)
        val ok = IntArray(1); glGetShaderiv(s, GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) Log.e("NeonCoast", "shader error: " + glGetShaderInfoLog(s))
        return s
    }

    private fun link(v: String, f: String): Int {
        val p = glCreateProgram()
        glAttachShader(p, sh(GL_VERTEX_SHADER, v)); glAttachShader(p, sh(GL_FRAGMENT_SHADER, f))
        glLinkProgram(p)
        return p
    }

    private fun cubeData(): FloatArray {
        val out = ArrayList<Float>()
        val faces = arrayOf(
            floatArrayOf(1f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 1f), floatArrayOf(-1f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 1f),
            floatArrayOf(0f, 1f, 0f, 1f, 0f, 0f, 0f, 0f, 1f), floatArrayOf(0f, -1f, 0f, 1f, 0f, 0f, 0f, 0f, 1f),
            floatArrayOf(0f, 0f, 1f, 1f, 0f, 0f, 0f, 1f, 0f), floatArrayOf(0f, 0f, -1f, 1f, 0f, 0f, 0f, 1f, 0f)
        )
        val q = arrayOf(
            floatArrayOf(-1f, -1f), floatArrayOf(1f, -1f), floatArrayOf(1f, 1f),
            floatArrayOf(-1f, -1f), floatArrayOf(1f, 1f), floatArrayOf(-1f, 1f)
        )
        for (f in faces) for (c in q) {
            for (k in 0..2) out.add(f[k] * .5f + f[3 + k] * c[0] * .5f + f[6 + k] * c[1] * .5f)
            out.add(f[0]); out.add(f[1]); out.add(f[2])
        }
        return out.toFloatArray()
    }

    private fun fbuf(a: FloatArray) = ByteBuffer.allocateDirect(a.size * 4).order(ByteOrder.nativeOrder())
        .asFloatBuffer().apply { put(a); position(0) }

    override fun onSurfaceCreated(gl: GL10?, c: EGLConfig?) {
        prog = link(VS, FS); skyProg = link(SVS, SFS)
        uVP = glGetUniformLocation(prog, "uVP"); uM = glGetUniformLocation(prog, "uM")
        uCol = glGetUniformLocation(prog, "uCol"); uSun = glGetUniformLocation(prog, "uSun")
        uCam = glGetUniformLocation(prog, "uCam"); uFog = glGetUniformLocation(prog, "uFog")
        uWin = glGetUniformLocation(prog, "uWin"); uEmis = glGetUniformLocation(prog, "uEmis")
        uRoad = glGetUniformLocation(prog, "uRoad")
        aPos = glGetAttribLocation(prog, "aPos"); aNrm = glGetAttribLocation(prog, "aNrm")
        sPos = glGetAttribLocation(skyProg, "p"); sHor = glGetUniformLocation(skyProg, "uHor")
        val ids = IntArray(2); glGenBuffers(2, ids, 0); cubeVbo = ids[0]; quadVbo = ids[1]
        val cd = cubeData()
        glBindBuffer(GL_ARRAY_BUFFER, cubeVbo)
        glBufferData(GL_ARRAY_BUFFER, cd.size * 4, fbuf(cd), GL_STATIC_DRAW)
        val qd = floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)
        glBindBuffer(GL_ARRAY_BUFFER, quadVbo)
        glBufferData(GL_ARRAY_BUFFER, qd.size * 4, fbuf(qd), GL_STATIC_DRAW)
        glEnable(GL_DEPTH_TEST)
        last = System.nanoTime()
    }

    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
        glViewport(0, 0, w, h)
        aspect = w.toFloat() / max(1, h)
    }

    override fun onDrawFrame(gl: GL10?) {
        val now = System.nanoTime()
        val dt = min(.05f, (now - last) / 1e9f)
        last = now
        G.update(dt)
        draw()
    }

    private fun vis(x: Float, z: Float, r: Float): Boolean {
        val dx = x - G.ex; val dz = z - G.ez
        return dx * dx + dz * dz < r * r
    }

    private fun box(
        cx: Float, cy: Float, cz: Float, sx: Float, sy: Float, sz: Float, ry: Float,
        r: Float, g: Float, b: Float, win: Float = 0f, em: Float = 0f, road: Float = 0f, rcn: Float = 0f
    ) {
        Matrix.setIdentityM(mm, 0)
        Matrix.translateM(mm, 0, cx, cy, cz)
        if (ry != 0f) Matrix.rotateM(mm, 0, ry, 0f, 1f, 0f)
        Matrix.scaleM(mm, 0, sx, sy, sz)
        glUniformMatrix4fv(uM, 1, false, mm, 0)
        glUniform3f(uCol, r, g, b); glUniform1f(uWin, win); glUniform1f(uEmis, em)
        glUniform2f(uRoad, road, rcn)
        glDrawArrays(GL_TRIANGLES, 0, 36)
    }

    // part in local car/person space (heading h)
    private fun part(
        x: Float, y: Float, z: Float, h: Float, lx: Float, ly: Float, lz: Float,
        sx: Float, sy: Float, sz: Float, c: FloatArray, em: Float = 0f
    ) {
        val s = sin(h); val co = cos(h)
        box(x + lx * co + lz * s, y + ly, z - lx * s + lz * co, sx, sy, sz,
            Math.toDegrees(h.toDouble()).toFloat(), c[0], c[1], c[2], 0f, em)
    }

    private val GLASS = floatArrayOf(.06f, .08f, .11f)
    private val TIRE = floatArrayOf(.05f, .05f, .05f)
    private val WHITE = floatArrayOf(.95f, .95f, .95f)
    private val HEAD = floatArrayOf(1f, .95f, .7f)
    private val TAIL = floatArrayOf(1f, .1f, .1f)
    private val RED = floatArrayOf(1f, .05f, .05f)
    private val BLUE = floatArrayOf(.1f, .3f, 1f)
    private val DARK = floatArrayOf(.07f, .07f, .08f)

    private fun drawCar(c: Car) {
        val y = G.gy(c.x, c.z)
        val body = if (c.type == 4) floatArrayOf(.12f, .12f, .12f) else c.col
        part(c.x, y, c.z, c.h, 0f, .7f, 0f, 2.1f, .75f, 4.5f, body)
        part(c.x, y, c.z, c.h, 0f, 1.38f, -.2f, 1.8f, .65f, 2.3f, GLASS)
        for (sx in floatArrayOf(-1f, 1f)) for (sz in floatArrayOf(-1.4f, 1.4f))
            part(c.x, y, c.z, c.h, sx * 1.05f, .4f, sz, .3f, .8f, .8f, TIRE)
        if (c.type != 4) for (sx in floatArrayOf(-.7f, .7f)) {
            part(c.x, y, c.z, c.h, sx, .8f, 2.26f, .5f, .2f, .1f, HEAD, 1f)
            part(c.x, y, c.z, c.h, sx, .8f, -2.26f, .5f, .2f, .1f, TAIL, .8f)
        }
        if (c.type == 2) {
            part(c.x, y, c.z, c.h, 0f, .68f, 0f, 2.14f, .35f, 2.2f, WHITE)
            val f = ((G.time * 6f).toInt() % 2 == 0)
            part(c.x, y, c.z, c.h, -.5f, 1.78f, -.2f, .6f, .18f, .4f, RED, if (f) 1.5f else .1f)
            part(c.x, y, c.z, c.h, .5f, 1.78f, -.2f, .6f, .18f, .4f, BLUE, if (f) .1f else 1.5f)
        }
    }

    private fun human(x: Float, y: Float, z: Float, h: Float, ph: Float, ci: Int, moving: Boolean, aim: Boolean, dead: Boolean) {
        val sh = G.SHIRT[ci % G.SHIRT.size]; val pa = G.PANTS[ci % 3]; val sk = G.SKIN[ci % 4]
        if (dead) {
            part(x, y, z, h, 0f, .22f, 0f, .7f, .3f, 1.5f, sh)
            part(x, y, z, h, 0f, .22f, 1f, .4f, .4f, .4f, sk)
            return
        }
        val sw = if (moving) sin(ph) * .35f else 0f
        part(x, y, z, h, 0f, 1.35f, 0f, .7f, .8f, .38f, sh)
        part(x, y, z, h, 0f, 1.98f, 0f, .4f, .42f, .4f, sk)
        part(x, y, z, h, 0f, 2.14f, -.02f, .44f, .14f, .44f, DARK)
        part(x, y, z, h, -.18f, .48f, sw, .28f, .95f, .28f, pa)
        part(x, y, z, h, .18f, .48f, -sw, .28f, .95f, .28f, pa)
        part(x, y, z, h, -.48f, 1.3f, -sw, .2f, .75f, .2f, sh)
        if (aim) {
            part(x, y, z, h, .48f, 1.55f, .4f, .2f, .2f, .8f, sh)
            part(x, y, z, h, .48f, 1.55f, .9f, .1f, .16f, .5f, DARK)
        } else part(x, y, z, h, .48f, 1.3f, sw, .2f, .75f, .2f, sh)
    }

    private fun draw() {
        val fog = floatArrayOf(.97f, .72f, .5f)
        glClearColor(fog[0], fog[1], fog[2], 1f)
        glClear(GL_COLOR_BUFFER_BIT or GL_DEPTH_BUFFER_BIT)

        Matrix.setLookAtM(view, 0, G.ex, G.ey, G.ez, G.tx, G.ty, G.tz, 0f, 1f, 0f)
        Matrix.perspectiveM(proj, 0, G.fov, aspect, .3f, 2500f)
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0)

        // sky
        val hd = hypot(G.tx - G.ex, G.tz - G.ez)
        val pitch = atan2(G.ey - G.ty, hd)
        val hor = tan(pitch) / tan(Math.toRadians((G.fov / 2f).toDouble()).toFloat())
        glDisable(GL_DEPTH_TEST)
        glUseProgram(skyProg)
        glUniform1f(sHor, hor)
        glBindBuffer(GL_ARRAY_BUFFER, quadVbo)
        glEnableVertexAttribArray(sPos)
        glVertexAttribPointer(sPos, 2, GL_FLOAT, false, 8, 0)
        glDrawArrays(GL_TRIANGLE_STRIP, 0, 4)
        glDisableVertexAttribArray(sPos)
        glEnable(GL_DEPTH_TEST)

        // world
        glUseProgram(prog)
        glBindBuffer(GL_ARRAY_BUFFER, cubeVbo)
        glEnableVertexAttribArray(aPos); glVertexAttribPointer(aPos, 3, GL_FLOAT, false, 24, 0)
        glEnableVertexAttribArray(aNrm); glVertexAttribPointer(aNrm, 3, GL_FLOAT, false, 24, 12)
        glUniformMatrix4fv(uVP, 1, false, vp, 0)
        glUniform3f(uSun, -.776f, .362f, -.517f)
        glUniform3f(uCam, G.ex, G.ey, G.ez)
        glUniform3f(uFog, fog[0], fog[1], fog[2])

        box(0f, -.65f, 0f, 9000f, .1f, 9000f, 0f, .11f, .43f, .55f, 0f, .15f)
        box(0f, -.05f, 0f, 2 * HALF + 120f, .1f, 2 * HALF + 120f, 0f, .85f, .78f, .6f)
        for (i in 0..GRID) {
            val c = rc(i)
            box(0f, .02f, c, 2 * HALF + ROAD, .04f, ROAD, 0f, .15f, .155f, .17f, 0f, 0f, 1f, c)
            box(c, .02f, 0f, ROAD, .04f, 2 * HALF + ROAD, 0f, .15f, .155f, .17f, 0f, 0f, 2f, c)
        }
        val S = CELL - ROAD
        for (i in 0 until GRID) for (j in 0 until GRID) {
            val cx = rc(i) + CELL / 2; val cz = rc(j) + CELL / 2
            if (vis(cx, cz, 420f)) box(cx, .15f, cz, S, .3f, S, 0f, .6f, .6f, .62f)
        }
        for (b in G.blds) if (vis(b.x, b.z, 520f))
            box(b.x, b.h / 2, b.z, b.w, b.h, b.d, 0f, b.c[0], b.c[1], b.c[2], b.seed)
        for (t in G.trees) if (vis(t[0], t[1], 170f)) {
            box(t[0], 3.8f, t[1], .5f, 7.6f, .5f, 0f, .42f, .29f, .17f)
            box(t[0], 7.6f, t[1], 4.2f, .7f, 4.2f, 0f, .18f, .55f, .28f)
            box(t[0], 7.9f, t[1], 4.2f, .7f, 4.2f, 45f, .2f, .6f, .3f)
        }

        val m = G.MIS.getOrNull(G.mi)
        if (m != null && m.type == 0) {
            box(m.gx, 70f, m.gz, 1.2f, 140f, 1.2f, 0f, 1f, .85f, 0f, 0f, 1f)
            box(m.gx, .4f, m.gz, 9f, .3f, 9f, G.time * 90f, 1f, .85f, 0f, 0f, 1f)
        }

        for (c in G.cars) if (vis(c.x, c.z, 320f)) drawCar(c)
        for (p in G.peds) if (vis(p.x, p.z, 130f))
            human(p.x, G.gy(p.x, p.z), p.z, p.h, p.ph, p.ci, p.st != 2, false, p.st == 2)
        if (G.pcar == null && !G.dead)
            human(G.px, G.py, G.pz, G.ph, G.phase, 0, G.pmove, G.aim > 0f, false)
        for (t in G.tracers) box(t[0], t[1], t[2], .06f, .06f, t[3], t[4], 1f, .9f, .5f, 0f, 1f)

        glDisableVertexAttribArray(aPos); glDisableVertexAttribArray(aNrm)
    }
}

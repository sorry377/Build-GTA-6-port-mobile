package com.neoncoast.game

import java.util.Random
import kotlin.math.*

const val PIf = 3.14159265f
const val GRID = 8
const val CELL = 80f
const val ROAD = 18f
const val HALF = 320f

fun rc(i: Int): Float = (i - GRID / 2) * CELL
fun angd(a: Float, b: Float): Float {
    var d = b - a
    while (d > PIf) d -= 2 * PIf
    while (d < -PIf) d += 2 * PIf
    return d
}

class Bld(val x: Float, val z: Float, val w: Float, val d: Float, val h: Float, val seed: Float, val c: FloatArray) {
    val x0 = x - w / 2; val x1 = x + w / 2; val z0 = z - d / 2; val z1 = z + d / 2
}

// type: 0 traffic, 1 parked, 2 police, 3 driven by player, 4 wreck
class Car(var type: Int, var x: Float, var z: Float, var h: Float, val col: FloatArray) {
    var speed = 0f; var hp = 100f; var ax = 0; var dir = 1; var lt = 0f; var wait = 0f
    var cr = 12f; var free = false; var t0 = 0f
}

// st: 0 walk, 1 flee, 2 dead
class Ped(var ax: Int, var lane: Float, var a: Float) {
    var ta = a; var sp = 1.5f; var st = 0; var t = 0f; var hp = 100f
    var fx = 0f; var fz = 0f; var x = 0f; var z = 0f; var h = 0f; var ph = 0f; var ci = 0
}

// type 1 = "get in any car", type 0 = go to point
class Mis(
    val t: String, val d: String, val type: Int, val gx: Float, val gz: Float,
    val needCar: Boolean, val needW0: Boolean, val reward: Int,
    val lines: List<String>, val onDone: (() -> Unit)?
)

object G {
    val rnd = Random(11)
    fun rf(a: Float, b: Float) = a + rnd.nextFloat() * (b - a)

    val blds = ArrayList<Bld>()
    val bmap = HashMap<Int, ArrayList<Bld>>()
    val trees = ArrayList<FloatArray>()
    val cars = ArrayList<Car>()
    val peds = ArrayList<Ped>()
    val tracers = ArrayList<FloatArray>() // cx, cy, cz, len, rotDeg, timeLeft
    val subQ = java.util.LinkedList<String>()

    val CARC = arrayOf(
        floatArrayOf(.75f, .22f, .17f), floatArrayOf(.17f, .48f, .9f), floatArrayOf(.95f, .76f, .06f),
        floatArrayOf(.09f, .63f, .52f), floatArrayOf(.92f, .94f, .95f), floatArrayOf(.56f, .27f, .68f),
        floatArrayOf(.13f, .13f, .14f), floatArrayOf(.9f, .5f, .13f)
    )
    val SHIRT = arrayOf(
        floatArrayOf(.83f, .33f, 0f), floatArrayOf(.16f, .5f, .73f), floatArrayOf(.15f, .68f, .38f),
        floatArrayOf(.56f, .27f, .68f), floatArrayOf(.92f, .94f, .95f), floatArrayOf(.95f, .61f, .07f),
        floatArrayOf(.2f, .29f, .37f)
    )
    val PANTS = arrayOf(floatArrayOf(.13f, .15f, .19f), floatArrayOf(.23f, .29f, .42f), floatArrayOf(.36f, .27f, .21f))
    val SKIN = arrayOf(floatArrayOf(.95f, .79f, .65f), floatArrayOf(.85f, .63f, .4f), floatArrayOf(.55f, .33f, .14f), floatArrayOf(.78f, .53f, .26f))

    // player
    var px = 12f; var pz = 12f; var py = .3f; var pvy = 0f; var ph = 0f; var hp = 100f
    var pcar: Car? = null
    var phase = 0f; var fireT = 0f; var aim = 0f; var pmove = false
    var camYaw = PIf; var camPitch = .35f; var lastDrag = 0f
    var ex = 12f; var ey = 6f; var ez = 19f; var tx = 12f; var ty = 1.6f; var tz = 12f; var fov = 65f
    var money = 0; var wanted = 0; var heatT = 0f; var time = 0f
    var dead = false; var deadT = 0f; var kills = 0; var mi = 0
    var spawnT = 0f; var subT = 0f; var sub = ""; var subA = 0f

    // input (written by UI thread)
    @Volatile var jx = 0f
    @Volatile var jy = 0f
    @Volatile var fire = false
    @Volatile var jump = false
    @Volatile var lookDX = 0f
    @Volatile var lookDY = 0f
    @Volatile var enterReq = false
    @Volatile var menu = false

    private var qx = 0f
    private var qz = 0f

    val MIS = listOf(
        Mis("ล้อหมุน", "ขึ้นรถสักคัน (กดปุ่ม ขึ้น/ลงรถ ใกล้ๆ รถ)", 1, 0f, 0f, false, false, 0,
            listOf("โคล (วิทยุ): \"รินา อย่ามัวยืนเฉย หารถสักคัน เวลาเรามีไม่มาก\""), null),
        Mis("ส่งของ", "ขับไปยังจุดสีเหลือง", 0, rc(2), rc(6), true, false, 800,
            listOf("โคล: \"ขับไปที่โกดังริมท่า คนของนายหน้ารออยู่\""), null),
        Mis("รับกระเป๋า", "ไปรับกระเป๋าที่จุดสีเหลือง", 0, rc(6), rc(2), false, false, 1200,
            listOf("นายหน้า: \"ได้ของแล้ว... แต่ตำรวจกำลังมา ไปให้พ้น!\""), { wanted = 2; heatT = 0f }),
        Mis("สลัดตำรวจ", "สลัดตำรวจให้ดาวเป็น 0 แล้วไปเซฟเฮาส์", 0, rc(1), rc(1), false, true, 1500,
            listOf("โคล: \"ตำรวจตามอยู่ สลัดมันก่อนค่อยเข้าเซฟเฮาส์\""), null),
        Mis("งานใหญ่", "เข้าไปที่ตึกธนาคาร (จุดสีเหลือง)", 0, rc(7), rc(6), false, false, 20000,
            listOf("รินา: \"งานสุดท้ายแล้ว... ทำให้จบ\""), { wanted = 4; heatT = 0f }),
        Mis("หนีออกทะเล", "ขับรถไปท่าเรือมุมเมือง ก่อนตำรวจจะตามทัน", 0, rc(0), rc(8), true, false, 50000,
            listOf("โคล: \"เรือรอที่ท่า! ไปเลยรินา!\""), null)
    )

    fun objText(): String {
        val m = MIS.getOrNull(mi) ?: return "อิสระ: เที่ยวเล่นในเมืองได้เลย"
        return "${m.t}: ${m.d}"
    }

    fun gy(x: Float, z: Float): Float {
        if (abs(x) >= HALF || abs(z) >= HALF) return 0f
        val a = (x + HALF) % CELL
        val b = (z + HALF) % CELL
        return if (a > ROAD / 2 && a < CELL - ROAD / 2 && b > ROAD / 2 && b < CELL - ROAD / 2) .3f else 0f
    }

    private fun push(r: Float): Boolean {
        var hit = false
        val i = floor((qx + HALF) / CELL).toInt()
        val j = floor((qz + HALF) / CELL).toInt()
        val l = bmap[i * 16 + j]
        if (l != null) for (b in l) {
            val cx = qx.coerceIn(b.x0, b.x1)
            val cz = qz.coerceIn(b.z0, b.z1)
            val dx = qx - cx
            val dz = qz - cz
            val d2 = dx * dx + dz * dz
            if (d2 < r * r) {
                hit = true
                if (d2 > 1e-6f) {
                    val d = sqrt(d2)
                    qx = cx + dx / d * r; qz = cz + dz / d * r
                } else {
                    val a = qx - b.x0; val bb = b.x1 - qx; val c = qz - b.z0; val dd = b.z1 - qz
                    val m = min(min(a, bb), min(c, dd))
                    if (m == a) qx = b.x0 - r else if (m == bb) qx = b.x1 + r else if (m == c) qz = b.z0 - r else qz = b.z1 + r
                }
            }
        }
        val L = HALF + 40f
        if (abs(qx) > L) { qx = qx.coerceIn(-L, L); hit = true }
        if (abs(qz) > L) { qz = qz.coerceIn(-L, L); hit = true }
        return hit
    }

    private fun buildCity() {
        val S = CELL - ROAD
        val hf = S / 2 - 6
        val bc = arrayOf(
            floatArrayOf(.32f, .36f, .45f), floatArrayOf(.45f, .38f, .4f),
            floatArrayOf(.3f, .4f, .42f), floatArrayOf(.5f, .45f, .38f)
        )
        for (i in 0 until GRID) for (j in 0 until GRID) {
            val cx = rc(i) + CELL / 2
            val cz = rc(j) + CELL / 2
            val dist = hypot(cx, cz) / HALF
            fun add(x: Float, z: Float, w: Float, d: Float) {
                val h = 14f + Math.pow(rnd.nextDouble(), 1.6).toFloat() * 110f * max(.25f, 1f - dist * .9f)
                val b = Bld(x, z, w, d, h, 1f + rnd.nextInt(50), bc[rnd.nextInt(4)])
                blds.add(b)
                bmap.getOrPut(i * 16 + j) { ArrayList() }.add(b)
            }
            val r = rnd.nextFloat()
            if (r < .3f) add(cx, cz, hf * 2, hf * 2)
            else if (r < .65f) {
                add(cx - hf / 2 - 1.5f, cz, hf - 3, hf * 2)
                add(cx + hf / 2 + 1.5f, cz, hf - 3, hf * 2)
            } else for (sx in intArrayOf(-1, 1)) for (sz in intArrayOf(-1, 1))
                add(cx + sx * (hf / 2 + 1.5f), cz + sz * (hf / 2 + 1.5f), hf - 3, hf - 3)
        }
        for (i in 0..GRID) for (j in 0 until GRID) for (s in intArrayOf(-1, 1)) for (k in 0 until 2)
            trees.add(floatArrayOf(rc(i) + s * 13f, rc(j) + 20f + k * 34f))
    }

    // ---------- cars ----------
    fun spawnCar(type: Int, x: Float, z: Float, h: Float, col: FloatArray): Car {
        val c = Car(type, x, z, h, col)
        cars.add(c)
        return c
    }

    private fun setLane(c: Car) {
        val li = (((if (c.ax == 1) c.x else c.z) + HALF) / CELL).roundToInt().coerceIn(0, GRID)
        c.lt = rc(li) + (if (c.ax == 1) -c.dir * 5f else c.dir * 5f)
    }

    private fun placeGrid(c: Car, ax: Int, dir: Int, a: Float, ri: Int) {
        c.ax = ax; c.dir = dir
        val l = rc(ri) + (if (ax == 1) -dir * 5f else dir * 5f)
        c.lt = l
        if (ax == 1) { c.z = a; c.x = l } else { c.x = a; c.z = l }
        c.h = if (ax == 1) (if (dir > 0) 0f else PIf) else (if (dir > 0) PIf / 2 else -PIf / 2)
    }

    private fun chk(c: Car, x: Float, z: Float): Boolean {
        val da = (if (c.ax == 1) z - c.z else x - c.x) * c.dir
        val dl = abs(if (c.ax == 1) x - c.x else z - c.z)
        return da > 0 && da < 10f && dl < 2.6f
    }

    private fun blocked(c: Car): Boolean {
        for (o in cars) { if (o === c) continue; if (chk(c, o.x, o.z)) return true }
        if (pcar == null && chk(c, px, pz)) return true
        return false
    }

    private fun gridMove(c: Car, dt: Float, sp: Float, chaseP: Boolean) {
        val a = if (c.ax == 1) c.z else c.x
        var l = if (c.ax == 1) c.x else c.z
        val na = a + c.dir * sp * dt
        l += (c.lt - l) * min(1f, dt * 3f)
        var ax = c.ax; var dir = c.dir; var aa = na; var ll = l
        val pi = floor((a + HALF) / CELL).toInt()
        val ni = floor((na + HALF) / CELL).toInt()
        if (pi != ni) {
            var nd = 0
            if (chaseP) {
                val vx = px - (if (ax == 1) l else na)
                val vz = pz - (if (ax == 1) na else l)
                val s0 = (if (ax == 1) vz else vx) * dir
                val s1 = if (ax == 1) vx else vz
                val s2 = -s1
                val m = max(s0, max(s1, s2))
                nd = if (m == s0) 0 else if (m == s1) 1 else -1
            } else if (rnd.nextFloat() < .4f) nd = if (rnd.nextBoolean()) 1 else -1
            if (nd != 0) { ax = 1 - ax; dir = nd; aa = l; ll = na }
        }
        if (abs(aa) > HALF + 6f) { dir = -dir; aa = aa.coerceIn(-HALF - 6f, HALF + 6f) }
        c.ax = ax; c.dir = dir
        if (ax == 1) { c.z = aa; c.x = ll } else { c.x = aa; c.z = ll }
        setLane(c)
        val ph2 = if (ax == 1) (if (dir > 0) 0f else PIf) else (if (dir > 0) PIf / 2 else -PIf / 2)
        c.h += angd(c.h, ph2) * min(1f, dt * 5f)
    }

    private fun chase(c: Car, dt: Float, d: Float) {
        val th = atan2(px - c.x, pz - c.z)
        c.h += angd(c.h, th).coerceIn(-1f, 1f) * dt * 2.5f
        c.speed += ((if (d > 9f) 26f else if (d > 5f) 6f else 0f) - c.speed) * dt * 1.5f
        c.x += sin(c.h) * c.speed * dt; c.z += cos(c.h) * c.speed * dt
        qx = c.x; qz = c.z; push(2.2f); c.x = qx; c.z = qz
    }

    private fun updateCars(dt: Float) {
        var n = cars.size - 1
        while (n >= 0) {
            val c = cars[n]; n--
            if (c.type == 0 || (c.type == 2 && !c.free)) {
                val b = blocked(c)
                c.wait = if (b) c.wait + dt else 0f
                val target = if (b && c.wait < 3f) 0f else (if (c.type == 2) 24f else c.cr)
                c.speed += (target - c.speed) * min(1f, dt * 2f)
                gridMove(c, dt, c.speed, c.type == 2)
            }
            if (c.type == 2) {
                val d = hypot(px - c.x, pz - c.z)
                if (d < 45f) c.free = true
                if (c.free) chase(c, dt, d)
                if ((c.free && d > 75f) || d > 260f) { cars.remove(c); continue }
                val pc = pcar
                if (d < 4.4f && pc != null) { pc.hp -= 14f * dt; pc.speed *= 1f - dt * .6f }
                if (d < 16f && pc == null && !dead) hp -= 3.5f * dt * wanted
            } else if (c.type == 1 || c.type == 4) {
                c.speed *= 1f - dt * 2f
                c.x += sin(c.h) * c.speed * dt; c.z += cos(c.h) * c.speed * dt
                if (c.type == 4 && time - c.t0 > 25f) cars.remove(c)
            }
        }
    }

    private fun updatePolice(dt: Float) {
        if (wanted == 0) {
            val it = cars.iterator()
            while (it.hasNext()) {
                val c = it.next()
                if (c.type == 2) { if (c.free) it.remove() else c.type = 0 }
            }
            return
        }
        var cnt = 0; var nd = 1e9f
        for (c in cars) if (c.type == 2) { cnt++; nd = min(nd, hypot(c.x - px, c.z - pz)) }
        heatT = if (nd > 70f) heatT + dt else 0f
        if (heatT > 12f) { wanted--; heatT = 0f }
        spawnT -= dt
        if (spawnT <= 0f && cnt < min(6, wanted + 1)) {
            spawnT = 1.5f
            val ax = rnd.nextInt(2)
            val dir = if (rnd.nextBoolean()) 1 else -1
            val base = if (ax == 1) px else pz
            val ri = ((base + HALF + rf(-90f, 90f)) / CELL).roundToInt().coerceIn(0, GRID)
            val a = ((if (ax == 1) pz else px) + (if (rnd.nextBoolean()) 1 else -1) * rf(110f, 160f)).coerceIn(-HALF, HALF)
            val c = spawnCar(2, 0f, 0f, 0f, floatArrayOf(.06f, .08f, .1f))
            placeGrid(c, ax, dir, a, ri)
            if (hypot(c.x - px, c.z - pz) < 90f) cars.remove(c)
        }
    }

    // ---------- peds ----------
    private fun spawnPed(far: Boolean) {
        val ax = rnd.nextInt(2)
        val lane = rc(rnd.nextInt(GRID + 1)) + (if (rnd.nextBoolean()) 10.5f else -10.5f)
        var a = rf(-HALF, HALF)
        var t = 0
        while (far && t < 10) {
            val x = if (ax == 1) lane else a
            val z = if (ax == 1) a else lane
            if (hypot(x - px, z - pz) > 50f) break
            a = rf(-HALF, HALF); t++
        }
        val p = Ped(ax, lane, a)
        p.sp = rf(1.2f, 2f); p.ci = rnd.nextInt(7)
        p.x = if (ax == 1) lane else a
        p.z = if (ax == 1) a else lane
        peds.add(p)
    }

    private fun killPed(p: Ped) {
        p.st = 2; p.t = 0f; kills++
        money += 20 + rnd.nextInt(100)
        wanted = max(wanted, 1); heatT = 0f
    }

    private fun scare(x: Float, z: Float, r: Float) {
        for (p in peds) if (p.st == 0 && hypot(p.x - x, p.z - z) < r) { p.st = 1; p.t = 0f; p.fx = x; p.fz = z }
    }

    private fun updatePeds(dt: Float) {
        var n = peds.size - 1
        while (n >= 0) {
            val p = peds[n]; n--
            p.t += dt
            if (p.st == 0) {
                val dir = if (p.ta >= p.a) 1f else -1f
                p.a += dir * p.sp * dt
                if (abs(p.ta - p.a) < 1f) p.ta = (p.a + rf(-120f, 120f)).coerceIn(-HALF, HALF)
                if (p.ax == 1) { p.x = p.lane; p.z = p.a } else { p.x = p.a; p.z = p.lane }
                p.h = if (p.ax == 1) (if (dir > 0) 0f else PIf) else (if (dir > 0) PIf / 2 else -PIf / 2)
                p.ph += p.sp * dt * 3.2f
            } else if (p.st == 1) {
                val dx = p.x - p.fx; val dz = p.z - p.fz
                val d = max(.001f, hypot(dx, dz))
                p.x += dx / d * 6.5f * dt; p.z += dz / d * 6.5f * dt
                qx = p.x; qz = p.z; push(.5f); p.x = qx; p.z = qz
                p.h = atan2(dx, dz); p.ph += dt * 16f
                if (p.t > 5f) { peds.removeAt(n + 1); spawnPed(true); continue }
            } else if (p.t > 6f) { peds.removeAt(n + 1); spawnPed(true); continue }
            val c = pcar
            if (c != null && p.st != 2 && abs(c.speed) > 6f && hypot(p.x - c.x, p.z - c.z) < 2.4f) killPed(p)
        }
    }

    // ---------- player ----------
    private fun shoot() {
        fireT = .16f; aim = .35f
        val fx = -sin(camYaw); val fz = -cos(camYaw)
        var dx = fx; var dz = fz
        var bestP: Ped? = null; var bestC: Car? = null; var ba = .93f
        for (p in peds) if (p.st != 2) {
            val vx = p.x - px; val vz = p.z - pz; val d = hypot(vx, vz)
            if (d in 2f..60f) { val cs = (vx * fx + vz * fz) / d; if (cs > ba) { ba = cs; bestP = p; bestC = null } }
        }
        for (c in cars) if (c.type == 2) {
            val vx = c.x - px; val vz = c.z - pz; val d = hypot(vx, vz)
            if (d in 2f..60f) { val cs = (vx * fx + vz * fz) / d; if (cs > ba) { ba = cs; bestC = c; bestP = null } }
        }
        val tp = bestP; val tc = bestC
        var dist = 60f
        var hx = 0f; var hz = 0f; var has = false
        if (tp != null) { hx = tp.x; hz = tp.z; has = true } else if (tc != null) { hx = tc.x; hz = tc.z; has = true }
        if (has) {
            val d = max(.01f, hypot(hx - px, hz - pz))
            dx = (hx - px) / d; dz = (hz - pz) / d; dist = d
        }
        ph = atan2(dx, dz)
        if (tp != null) {
            tp.hp -= 60f
            if (tp.hp <= 0f) killPed(tp) else { tp.st = 1; tp.t = 0f; tp.fx = px; tp.fz = pz }
        }
        if (tc != null) {
            tc.hp -= 22f; wanted = max(wanted, 2); heatT = 0f
            if (tc.hp <= 0f) { cars.remove(tc); wanted = min(5, wanted + 1) }
        }
        scare(px, pz, 28f)
        tracers.add(floatArrayOf(px + dx * dist / 2, py + 1.4f, pz + dz * dist / 2, dist, Math.toDegrees(ph.toDouble()).toFloat(), .07f))
    }

    private fun walkP(dt: Float) {
        val fx = -sin(camYaw); val fz = -cos(camYaw)
        val rx = -fz; val rz = fx
        var mx = fx * jy + rx * jx
        var mz = fz * jy + rz * jx
        val m = hypot(mx, mz)
        pmove = m > .1f
        if (pmove) {
            val s = min(1f, m)
            val run = if (m > .85f) 6.5f else 4f
            mx /= m; mz /= m
            px += mx * run * s * dt; pz += mz * run * s * dt
            ph += angd(ph, atan2(mx, mz)) * min(1f, dt * 12f)
            phase += run * s * dt * 2.2f
        }
        fireT -= dt; aim -= dt
        if (fire && fireT <= 0f) shoot()
        qx = px; qz = pz; push(.6f); px = qx; pz = qz
        val g = gy(px, pz)
        if (jump && py <= g + .02f && pvy == 0f) pvy = 7f
        pvy -= 22f * dt; py += pvy * dt
        if (py < g) { py = g; pvy = 0f }
    }

    private fun driveP(dt: Float) {
        val c = pcar ?: return
        if (jy > .1f) c.speed += jy * 20f * (1f - max(0f, c.speed) / 48f) * dt
        else if (jy < -.1f) c.speed += jy * (if (c.speed > 1f) 50f else 14f) * dt
        else c.speed *= 1f - .35f * dt
        if (jump) c.speed -= sign(c.speed) * min(abs(c.speed), 70f * dt)
        c.speed = c.speed.coerceIn(-14f, 42f)
        c.h -= jx * dt * 1.9f * (abs(c.speed) / 8f).coerceIn(0f, 1f) * sign(c.speed) * (1f - min(.5f, abs(c.speed) / 90f))
        c.x += sin(c.h) * c.speed * dt; c.z += cos(c.h) * c.speed * dt
        val s0 = abs(c.speed)
        qx = c.x; qz = c.z
        if (push(2.1f)) { c.speed *= .4f; if (s0 > 10f) c.hp -= s0 * .8f }
        c.x = qx; c.z = qz
        val rm = ArrayList<Car>()
        for (o in cars) {
            if (o === c) continue
            val dx = c.x - o.x; val dz = c.z - o.z; val d = hypot(dx, dz)
            if (d < 3.8f && d > .01f) {
                val n = 3.8f - d
                c.x += dx / d * n * .6f; c.z += dz / d * n * .6f
                o.x -= dx / d * n * .4f; o.z -= dz / d * n * .4f
                if (abs(c.speed) > 8f) {
                    c.hp -= abs(c.speed) * .25f; c.speed *= .6f
                    if (o.type == 2) {
                        o.hp -= 15f; wanted = max(wanted, 2); heatT = 0f
                        if (o.hp <= 0f) { rm.add(o); wanted = min(5, wanted + 1) }
                    }
                }
            }
        }
        for (o in rm) cars.remove(o)
        px = c.x; pz = c.z; py = gy(px, pz)
        if (c.hp <= 0f) { c.type = 4; c.t0 = time; pcar = null; hp -= 25f; px += 3f }
    }

    private fun enterExit() {
        if (dead) return
        val c0 = pcar
        if (c0 != null) {
            val rx = -cos(c0.h); val rz = sin(c0.h)
            c0.type = 1; c0.speed = 0f
            px = c0.x + rx * 2.8f; pz = c0.z + rz * 2.8f
            pcar = null; py = gy(px, pz)
            return
        }
        var best: Car? = null; var bd = 5.5f
        for (c in cars) {
            if (c.type == 4 || c.type == 3) continue
            val d = hypot(c.x - px, c.z - pz)
            if (d < bd) { bd = d; best = c }
        }
        if (best != null) {
            if (best.type == 2) wanted = max(wanted, 2)
            best.type = 3; best.free = false; best.speed = 0f
            pcar = best
        }
    }

    private fun die() { dead = true; deadT = 3f }
    private fun respawn() {
        val c = pcar
        if (c != null) { c.type = 1; pcar = null }
        px = 12f; pz = 12f; py = .3f; hp = 100f; wanted = 0
        money = max(0, money - 500); dead = false
    }

    // ---------- missions ----------
    private fun nextMission() {
        val m = MIS[mi]
        money += m.reward; hp = 100f
        m.onDone?.invoke()
        mi++
        val n = MIS.getOrNull(mi)
        if (n != null) { subQ.add("ภารกิจใหม่: ${n.t}"); subQ.addAll(n.lines) }
        else subQ.add("จบบทที่ 1 — ขอบคุณที่เล่น Neon Coast! เที่ยวต่อได้เลย")
    }

    private fun mission() {
        val m = MIS.getOrNull(mi) ?: return
        if (m.type == 1) { if (pcar != null) nextMission(); return }
        if (hypot(px - m.gx, pz - m.gz) < 9f) {
            if (m.needCar && pcar == null) return
            if (m.needW0 && wanted > 0) return
            nextMission()
        }
    }

    private fun updateCam(dt: Float) {
        val c = pcar
        val ttx = if (c != null) c.x else px
        val tty = if (c != null) 1.6f else py + 1.6f
        val ttz = if (c != null) c.z else pz
        if (c != null && c.speed > 3f && time - lastDrag > 1.5f) camYaw += angd(camYaw, c.h + PIf) * min(1f, dt * 2.2f)
        val d = if (c != null) 11f else 6.5f
        val cp = cos(camPitch)
        val dx = ttx + sin(camYaw) * cp * d
        val dy = max(.6f, tty + sin(camPitch) * d)
        val dz = ttz + cos(camYaw) * cp * d
        val k = min(1f, dt * 10f)
        ex += (dx - ex) * k; ey += (dy - ey) * k; ez += (dz - ez) * k
        tx = ttx; ty = tty; tz = ttz
        val tf = 65f + (if (c != null) max(0f, c.speed) * .4f else 0f)
        fov += (tf - fov) * min(1f, dt * 4f)
    }

    fun update(dt: Float) {
        if (menu) return
        time += dt; subT -= dt
        camYaw -= lookDX * .006f
        camPitch = (camPitch + lookDY * .004f).coerceIn(.05f, 1.2f)
        if (lookDX != 0f || lookDY != 0f) lastDrag = time
        lookDX = 0f; lookDY = 0f
        if (enterReq) { enterReq = false; enterExit() }
        if (!dead) { if (pcar != null) driveP(dt) else walkP(dt) }
        updateCars(dt); updatePeds(dt); updatePolice(dt); mission(); updateCam(dt)
        val it = tracers.iterator()
        while (it.hasNext()) { val t = it.next(); t[5] -= dt; if (t[5] <= 0f) it.remove() }
        if (subT <= 0f) {
            val s = subQ.poll()
            if (s != null) { sub = s; subA = 1f; subT = 3.8f } else subA = 0f
        }
        if (hp <= 0f && !dead) die()
        if (dead) { deadT -= dt; if (deadT <= 0f) respawn() }
    }

    init {
        buildCity()
        repeat(26) {
            val c = spawnCar(0, 0f, 0f, 0f, CARC[rnd.nextInt(CARC.size)])
            placeGrid(c, rnd.nextInt(2), if (rnd.nextBoolean()) 1 else -1, rf(-HALF, HALF), 1 + rnd.nextInt(GRID - 1))
            c.cr = rf(10f, 16f)
            if (hypot(c.x - px, c.z - pz) < 60f) placeGrid(c, c.ax, c.dir, -250f, 2)
        }
        spawnCar(1, 6.5f, 24f, 0f, CARC[1])
        spawnCar(1, -6.5f, 40f, PIf, CARC[0])
        spawnCar(1, 6.5f, 60f, 0f, CARC[3])
        spawnCar(1, rc(5) + 6.5f, rc(5) + 10f, 0f, CARC[2])
        spawnCar(1, rc(3) + 6.5f, rc(6) - 30f, 0f, CARC[5])
        spawnCar(1, rc(6) - 6.5f, rc(2) + 30f, PIf, CARC[7])
        repeat(70) { spawnPed(true) }
        subQ.add("รินา เวล กลับมานีออนโคสต์ เพื่องานสุดท้ายก่อนจะหนีไปตลอดกาล...")
        subQ.addAll(MIS[0].lines)
    }
}

package com.neoncoast.game

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.*

class Hud(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val MS = 760
    private val map: Bitmap = makeMap()
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)

    private var joyId = -1; private var jcx = 0f; private var jcy = 0f; private var jdx = 0f; private var jdy = 0f
    private var lookId = -1; private var lx = 0f; private var ly = 0f
    private var fireId = -1; private var jumpId = -1
    private var tab = 0

    private fun makeMap(): Bitmap {
        val b = Bitmap.createBitmap(MS, MS, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val q = Paint()
        val half = MS / 2f
        q.color = 0xFF0F3A52.toInt(); c.drawRect(0f, 0f, MS.toFloat(), MS.toFloat(), q)
        q.color = 0xFFBBA978.toInt(); c.drawRect(half - HALF - 60, half - HALF - 60, half + HALF + 60, half + HALF + 60, q)
        q.color = 0xFF8892A0.toInt()
        for (i in 0..GRID) {
            val r = rc(i)
            c.drawRect(half + r - ROAD / 2, half - HALF - ROAD / 2, half + r + ROAD / 2, half + HALF + ROAD / 2, q)
            c.drawRect(half - HALF - ROAD / 2, half + r - ROAD / 2, half + HALF + ROAD / 2, half + r + ROAD / 2, q)
        }
        q.color = 0xFF3D4A5E.toInt()
        for (bl in G.blds) c.drawRect(half + bl.x0, half + bl.z0, half + bl.x1, half + bl.z1, q)
        return b
    }

    // ---------- layout ----------
    private fun fireC() = floatArrayOf(width - 95 * d, height - 95 * d, 55 * d)
    private fun jumpC() = floatArrayOf(width - 205 * d, height - 70 * d, 42 * d)
    private fun enterC() = floatArrayOf(width - 95 * d, height - 210 * d, 42 * d)
    private fun menuC() = floatArrayOf(width - 40 * d, 40 * d, 28 * d)
    private fun hit(c: FloatArray, x: Float, y: Float) = hypot(x - c[0], y - c[1]) < c[2] * 1.15f

    // ---------- touch ----------
    override fun onTouchEvent(e: MotionEvent): Boolean {
        val a = e.actionMasked; val ai = e.actionIndex
        if (G.menu) {
            if (a == MotionEvent.ACTION_DOWN) menuTap(e.x, e.y)
            return true
        }
        when (a) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> down(e.getPointerId(ai), e.getX(ai), e.getY(ai))
            MotionEvent.ACTION_MOVE -> for (i in 0 until e.pointerCount) move(e.getPointerId(i), e.getX(i), e.getY(i))
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> up(e.getPointerId(ai))
            MotionEvent.ACTION_CANCEL -> for (i in 0 until e.pointerCount) up(e.getPointerId(i))
        }
        return true
    }

    private fun down(id: Int, x: Float, y: Float) {
        when {
            hit(menuC(), x, y) -> {
                G.menu = true; G.jx = 0f; G.jy = 0f; G.fire = false; G.jump = false
                joyId = -1; lookId = -1; fireId = -1; jumpId = -1
            }
            hit(fireC(), x, y) -> { fireId = id; G.fire = true }
            hit(jumpC(), x, y) -> { jumpId = id; G.jump = true }
            hit(enterC(), x, y) -> G.enterReq = true
            x < width * .38f && joyId < 0 -> { joyId = id; jcx = x; jcy = y; jdx = 0f; jdy = 0f }
            lookId < 0 -> { lookId = id; lx = x; ly = y }
        }
    }

    private fun move(id: Int, x: Float, y: Float) {
        if (id == joyId) {
            var dx = x - jcx; var dy = y - jcy
            val r = 60f * d; val m = hypot(dx, dy)
            if (m > r) { dx *= r / m; dy *= r / m }
            jdx = dx; jdy = dy
            G.jx = dx / r; G.jy = -dy / r
        } else if (id == lookId) {
            G.lookDX += x - lx; G.lookDY += y - ly
            lx = x; ly = y
        }
    }

    private fun up(id: Int) {
        if (id == joyId) { joyId = -1; G.jx = 0f; G.jy = 0f; jdx = 0f; jdy = 0f }
        if (id == lookId) lookId = -1
        if (id == fireId) { fireId = -1; G.fire = false }
        if (id == jumpId) { jumpId = -1; G.jump = false }
    }

    private fun menuTap(x: Float, y: Float) {
        if (y < 66 * d) {
            if (x > width - 90 * d) { G.menu = false; return }
            val i = ((x - 20 * d) / (140 * d)).toInt()
            if (i in 0..2) tab = i
        }
    }

    // ---------- drawing ----------
    private fun txt(c: Canvas, s: String, x: Float, y: Float, size: Float, col: Int, al: Paint.Align = Paint.Align.LEFT, bold: Boolean = true) {
        tp.textSize = size * d; tp.color = col; tp.textAlign = al
        tp.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        tp.setShadowLayer(3f * d, 0f, 1f * d, Color.BLACK)
        c.drawText(s, x, y, tp)
        tp.clearShadowLayer()
    }

    private fun button(c: Canvas, b: FloatArray, label: String, col: Int) {
        p.style = Paint.Style.FILL; p.color = col; c.drawCircle(b[0], b[1], b[2], p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 2 * d; p.color = 0xAAFFFFFF.toInt(); c.drawCircle(b[0], b[1], b[2], p)
        txt(c, label, b[0], b[1] + 5 * d, 14f, Color.WHITE, Paint.Align.CENTER)
    }

    private fun arrow(c: Canvas, x: Float, y: Float, deg: Float, s: Float) {
        c.save(); c.translate(x, y); c.rotate(deg)
        val path = Path()
        path.moveTo(0f, -14 * s); path.lineTo(10 * s, 12 * s); path.lineTo(0f, 6 * s); path.lineTo(-10 * s, 12 * s); path.close()
        p.style = Paint.Style.FILL; p.color = Color.WHITE; c.drawPath(path, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = Color.BLACK; c.drawPath(path, p)
        c.restore()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        if (G.menu) drawMenu(c, w, h) else drawHud(c, w, h)
        postInvalidateOnAnimation()
    }

    private fun drawHud(c: Canvas, w: Float, h: Float) {
        // minimap
        val r = 75 * d; val cx = 14 * d + r; val cy = 14 * d + r
        val k = .85f * d
        val fx = -sin(G.camYaw); val fz = -cos(G.camYaw)
        val th = -PIf / 2 - atan2(fz, fx)
        val path = Path(); path.addCircle(cx, cy, r, Path.Direction.CW)
        c.save(); c.clipPath(path)
        p.style = Paint.Style.FILL; p.color = 0xFF0F3A52.toInt(); c.drawCircle(cx, cy, r, p)
        c.translate(cx, cy); c.rotate(Math.toDegrees(th.toDouble()).toFloat()); c.scale(k, k); c.translate(-G.px, -G.pz)
        c.drawBitmap(map, -MS / 2f, -MS / 2f, bmpPaint)
        c.restore()
        fun blip(x: Float, z: Float, col: Int, rad: Float) {
            val dx = x - G.px; val dz = z - G.pz
            var rx = (dx * cos(th) - dz * sin(th)) * k
            var ry = (dx * sin(th) + dz * cos(th)) * k
            val m = hypot(rx, ry); val lim = r - 10 * d
            if (m > lim) { rx *= lim / m; ry *= lim / m }
            p.style = Paint.Style.FILL; p.color = col; c.drawCircle(cx + rx, cy + ry, rad * d, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 1.5f * d; p.color = Color.BLACK; c.drawCircle(cx + rx, cy + ry, rad * d, p)
        }
        val ms = G.MIS.getOrNull(G.mi)
        if (ms != null && ms.type == 0) blip(ms.gx, ms.gz, 0xFFFFD400.toInt(), 5f)
        val flash = (G.time * 4).toInt() % 2 == 0
        for (cr in G.cars) if (cr.type == 2) blip(cr.x, cr.z, if (flash) 0xFFFF3333.toInt() else 0xFF3399FF.toInt(), 3.5f)
        val hd = G.pcar?.h ?: G.ph
        arrow(c, cx, cy, Math.toDegrees((atan2(cos(hd), sin(hd)) + th + PIf / 2).toDouble()).toFloat(), d * .8f)
        p.style = Paint.Style.STROKE; p.strokeWidth = 3 * d; p.color = Color.WHITE; c.drawCircle(cx, cy, r, p)

        // health
        p.style = Paint.Style.FILL; p.color = 0x88000000.toInt(); c.drawRoundRect(14 * d, 172 * d, 164 * d, 182 * d, 5 * d, 5 * d, p)
        p.color = 0xFFEE4444.toInt(); c.drawRoundRect(14 * d, 172 * d, (14 + 150 * max(0f, G.hp) / 100f) * d, 182 * d, 5 * d, 5 * d, p)

        // money / stars
        txt(c, "$" + G.money, w - 85 * d, 34 * d, 28f, 0xFF8DFF9A.toInt(), Paint.Align.RIGHT)
        val sb = StringBuilder()
        for (i in 0 until 5) sb.append(if (i < G.wanted) "★" else "☆")
        val starCol = if (G.wanted > 1 && (G.time * 3).toInt() % 2 == 1) Color.WHITE else 0xFFFFD400.toInt()
        txt(c, sb.toString(), w - 85 * d, 66 * d, 24f, starCol, Paint.Align.RIGHT)

        // objective
        val obj = G.objText()
        tp.textSize = 15 * d
        val ow = min(w * .46f, tp.measureText(obj) + 28 * d)
        p.style = Paint.Style.FILL; p.color = 0x99000000.toInt()
        c.drawRoundRect(w / 2 - ow / 2, 8 * d, w / 2 + ow / 2, 40 * d, 8 * d, 8 * d, p)
        txt(c, obj, w / 2, 30 * d, 15f, Color.WHITE, Paint.Align.CENTER, false)

        // subtitles
        if (G.subA > 0f && G.sub.isNotEmpty()) {
            tp.textSize = 17 * d
            val sw = min(w * .55f, tp.measureText(G.sub) + 30 * d)
            p.color = 0xAA000000.toInt()
            c.drawRoundRect(w / 2 - sw / 2, h - 58 * d, w / 2 + sw / 2, h - 16 * d, 8 * d, 8 * d, p)
            txt(c, G.sub, w / 2, h - 30 * d, 17f, Color.WHITE, Paint.Align.CENTER, false)
        }

        // speed
        val pc = G.pcar
        if (pc != null) txt(c, (abs(pc.speed) * 3.6f).roundToInt().toString() + " km/h", w - 30 * d, h - 270 * d, 24f, Color.WHITE, Paint.Align.RIGHT)

        // controls
        if (joyId >= 0) {
            p.style = Paint.Style.FILL; p.color = 0x22FFFFFF; c.drawCircle(jcx, jcy, 60 * d, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 2 * d; p.color = 0x88FFFFFF.toInt(); c.drawCircle(jcx, jcy, 60 * d, p)
            p.style = Paint.Style.FILL; p.color = 0x99FFFFFF.toInt(); c.drawCircle(jcx + jdx, jcy + jdy, 30 * d, p)
        } else {
            p.style = Paint.Style.STROKE; p.strokeWidth = 2 * d; p.color = 0x44FFFFFF; c.drawCircle(130 * d, h - 120 * d, 60 * d, p)
        }
        button(c, fireC(), "ยิง", 0xAACC2222.toInt())
        button(c, jumpC(), if (G.pcar != null) "เบรก" else "กระโดด", 0x88000000.toInt())
        button(c, enterC(), "ขึ้น/ลง", 0x88000000.toInt())
        button(c, menuC(), "เมนู", 0x88000000.toInt())

        if (G.dead) {
            p.style = Paint.Style.FILL; p.color = 0x99440000.toInt(); c.drawRect(0f, 0f, w, h, p)
            txt(c, "ล้มลงแล้ว...", w / 2, h / 2, 44f, Color.WHITE, Paint.Align.CENTER)
        }
    }

    private fun drawMenu(c: Canvas, w: Float, h: Float) {
        p.style = Paint.Style.FILL; p.color = 0xEE000000.toInt(); c.drawRect(0f, 0f, w, h, p)
        val names = arrayOf("แผนที่", "ภารกิจ", "วิธีเล่น")
        for (i in 0..2) {
            val x = 20 * d + i * 140 * d
            p.style = Paint.Style.FILL; p.color = if (i == tab) 0xFF444444.toInt() else 0xFF222222.toInt()
            c.drawRoundRect(x, 14 * d, x + 130 * d, 58 * d, 8 * d, 8 * d, p)
            txt(c, names[i], x + 65 * d, 43 * d, 16f, Color.WHITE, Paint.Align.CENTER)
        }
        p.color = 0xFF662222.toInt(); c.drawRoundRect(w - 80 * d, 14 * d, w - 20 * d, 58 * d, 8 * d, 8 * d, p)
        txt(c, "✕", w - 50 * d, 44 * d, 20f, Color.WHITE, Paint.Align.CENTER)

        when (tab) {
            0 -> {
                val size = min(h - 90 * d, w - 40 * d)
                val ox = (w - size) / 2; val oy = 74 * d; val s = size / MS
                c.drawBitmap(map, null, RectF(ox, oy, ox + size, oy + size), bmpPaint)
                val ms = G.MIS.getOrNull(G.mi)
                p.style = Paint.Style.FILL
                if (ms != null && ms.type == 0) { p.color = 0xFFFFD400.toInt(); c.drawCircle(ox + (ms.gx + MS / 2f) * s, oy + (ms.gz + MS / 2f) * s, 9 * d, p) }
                p.color = 0xFFFF3333.toInt()
                for (cr in G.cars) if (cr.type == 2) c.drawCircle(ox + (cr.x + MS / 2f) * s, oy + (cr.z + MS / 2f) * s, 5 * d, p)
                val hd = G.pcar?.h ?: G.ph
                arrow(c, ox + (G.px + MS / 2f) * s, oy + (G.pz + MS / 2f) * s, Math.toDegrees((atan2(cos(hd), sin(hd)) + PIf / 2).toDouble()).toFloat(), d)
            }
            1 -> {
                val sb = StringBuilder("Neon Coast — บทที่ 1\nรินา เวล อดีตคนขับรถหนี กลับมาที่เมืองริมทะเล\nเพื่องานสุดท้ายกับโคล ก่อนจะทิ้งเมืองนี้ไปตลอดกาล\n\n")
                for ((i, m) in G.MIS.withIndex()) {
                    sb.append(if (i < G.mi) "✔ " else if (i == G.mi) "▶ " else "• ").append(m.t)
                    if (i == G.mi) sb.append(" — ").append(m.d)
                    sb.append("\n")
                }
                sb.append("\nเงิน: $").append(G.money).append("   ดาว: ").append(G.wanted).append("   ล้มลง: ").append(G.kills)
                lines(c, sb.toString(), 24 * d, 100 * d)
            }
            else -> lines(c,
                "จอยซ้าย = เดิน / ขับรถ (ขึ้น=เร่ง ลง=ถอย ซ้ายขวา=เลี้ยว)\n" +
                "ลากนิ้วฝั่งขวา = หมุนกล้อง\n" +
                "ปุ่มแดง = ยิง (เล็งอัตโนมัติ)\n" +
                "กระโดด / เบรก = กระโดดเมื่อเดิน, เบรกเมื่อขับ\n" +
                "ขึ้น/ลง = ใกล้รถแล้วกด (แย่งรถคนอื่นได้)\n\n" +
                "ฆ่าคนหรือชนตำรวจจะได้ดาว ตำรวจจะไล่\n" +
                "หนีให้ไกลประมาณ 12 วินาที ดาวจะลด", 24 * d, 100 * d)
        }
    }

    private fun lines(c: Canvas, s: String, x: Float, y0: Float) {
        var y = y0
        for (ln in s.split("\n")) { txt(c, ln, x, y, 17f, Color.WHITE, Paint.Align.LEFT, false); y += 30 * d }
    }
}
